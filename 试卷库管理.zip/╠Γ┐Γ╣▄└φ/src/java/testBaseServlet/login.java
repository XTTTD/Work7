/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package java.testBaseServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Administrator
 */
public class login extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        java.sql.Connection conn = null;        
        java.sql.PreparedStatement preparedStmt=null; //璇彞瀵硅薄 
        java.sql.ResultSet sqlRst = null; //缁撴灉闆嗗璞�
        
        request.setCharacterEncoding("UTF-8");
        String UserName = request.getParameter("userName");
        String Password = request.getParameter("password");
         DBConn dbcon = new DBConn();
        try {
           
            conn = dbcon.getConn();
            preparedStmt = conn.prepareStatement("select * from user where userName=? and password=?");
            //璁剧疆鍙傛暟
            preparedStmt.setString(1,  UserName);
            preparedStmt.setString(2, Password );
            //鎵цSql璇彞
            sqlRst = preparedStmt.executeQuery();
//            sqlRst.first();
//            System.out.println(sqlRst.getString(1));
//            System.out.println(sqlRst.getString(2));
            if (sqlRst.first()) {
             //   System.out.println("succ");
                HttpSession session = request.getSession();
                session.setAttribute("userName",UserName );
                if(sqlRst.getInt("userType")==1){
                    RequestDispatcher dispatcher = request.getRequestDispatcher("frame.html");
                    dispatcher.forward(request, response);
                }
                else{
                    RequestDispatcher dispatcher = request.getRequestDispatcher("user.jsp");
                    dispatcher.forward(request, response);
                }
            } else {
                System.out.println("fail");
                RequestDispatcher dispatcher = request.getRequestDispatcher("index.html");
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }finally{
            dbcon.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
