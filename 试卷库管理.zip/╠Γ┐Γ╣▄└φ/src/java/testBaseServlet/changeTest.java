/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testBaseServlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
public class changeTest extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
               response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        java.sql.Connection conn = null;
        java.sql.PreparedStatement preparedStmt=null; //语句对象
        java.sql.ResultSet sqlRst = null; //结果集对象
        request.setCharacterEncoding("UTF-8");
        FileInputStream fis = null;
        String testContent = request.getParameter("testContent");
        String AContent = request.getParameter("AContent");
        String BContent = request.getParameter("BContent");
        String CContent = request.getParameter("CContent");
        String DContent = request.getParameter("DContent");
        String answerSwitch = request.getParameter("answerSwitch");
        String answer= request.getParameter("answer");
        String testID = request.getParameter("testID");
        String testType=request.getParameter("testType");
        DBConn dbcon = new DBConn();
        String url;
        String filelocation = request.getParameter("file");
        try {
            conn = dbcon.getConn();
            if(testType.equals("1")){
                if(testContent==null||AContent==null||BContent==null||CContent==null||DContent==null||answerSwitch==null)
        {
            url="error.jsp?errorContent=题目选项不能为空!";
            RequestDispatcher dispatcher = request.getRequestDispatcher(url);
            dispatcher.forward(request, response);
            return ;
        }
                if (filelocation.length()==0){
                     preparedStmt = conn.prepareStatement("update test set testType=?,testContent=?,"
                    + "AContent=?,BContent=?,CContent=?,DContent=?,answer=? where testID=?");
                     preparedStmt.setInt(8, Integer.parseInt(testID));
                }else{
                    File files = new File(filelocation);
                    fis = new FileInputStream(files);
                    preparedStmt = conn.prepareStatement("update test set testType=?,testContent=?,"
                    + "AContent=?,BContent=?,CContent=?,DContent=?,answer=?,testImage=? where testID=?");
                    preparedStmt.setBinaryStream(8, fis, (int) files.length());
                    preparedStmt.setInt(9, Integer.parseInt(testID));
            }
            //设置参数
            //选择题类型为1
            preparedStmt.setInt(1,1);
            preparedStmt.setString(2, testContent );
            preparedStmt.setString(3, AContent );
            preparedStmt.setString(4, BContent );
            preparedStmt.setString(5, CContent );
            preparedStmt.setString(6, DContent );
            preparedStmt.setString(7, answerSwitch );
            }
            else{
                if(testContent==null||answer==null)
        {
            url="error.jsp?errorContent=题目选项不能为空!";
            RequestDispatcher dispatcher = request.getRequestDispatcher(url);
            dispatcher.forward(request, response);
            return ;
        }
                if (filelocation.length()==0){
                    preparedStmt = conn.prepareStatement("update test set testType=?,testContent=?,"
                    + "answer=? where testID=?");
                    preparedStmt.setInt(4, Integer.parseInt(testID));
                }else{
                    File files = new File(filelocation);
                    fis = new FileInputStream(files);
                    preparedStmt = conn.prepareStatement("update test set testType=?,testContent=?,"
                    + "answer=?,testImage=? where testID=?");
                    preparedStmt.setBinaryStream(4, fis, (int) files.length());
                    preparedStmt.setInt(5, Integer.parseInt(testID));
                }
            
            //设置参数
            //选择题类型为1
            preparedStmt.setInt(1,2);
            preparedStmt.setString(2, testContent );
            preparedStmt.setString(3, answer );
            }
            if(preparedStmt.executeUpdate()==1){
                //题目内容增加成功
                url="updateTest.jsp?isOk=ok";
                RequestDispatcher dispatcher = request.getRequestDispatcher(url);
                dispatcher.forward(request, response);
            }
            else{
            //跳转到错误页面
                url="error.jsp?errorContent=题目修改失败";
                RequestDispatcher dispatcher = request.getRequestDispatcher(url);
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }finally{
            dbcon.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
