/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testBaseServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
public class deleteTest extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        java.sql.Connection conn = null;
        java.sql.PreparedStatement preparedStmt=null; //语句对象
        java.sql.ResultSet sqlRst = null; //结果集对象

        request.setCharacterEncoding("UTF-8");
        String testID = request.getParameter("testID");
        String page = request.getParameter("page");
        DBConn dbcon = new DBConn();
        try {
            conn = dbcon.getConn();
            preparedStmt = conn.prepareStatement("delete from test where testID=?");
            //设置参数
            preparedStmt.setString(1,  testID);
            //执行Sql语句
//            preparedStmt.executeUpdate();
//            sqlRst.first();
//            System.out.println(sqlRst.getString(1));
//            System.out.println(sqlRst.getString(2));
            String url;
            if (preparedStmt.executeUpdate()==1) {
//                System.out.println(url);
                url = "updateTest.jsp"+"?page="+page;
                RequestDispatcher dispatcher = request.getRequestDispatcher(url);
                dispatcher.forward(request, response);
            } else {
//                System.out.println(url);
                url = "error.jsp"+"?errorContent="+"操作数据库的题目删除出错！";
                RequestDispatcher dispatcher = request.getRequestDispatcher(url);
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        }finally{
            dbcon.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
