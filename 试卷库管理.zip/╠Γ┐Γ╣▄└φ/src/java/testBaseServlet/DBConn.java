/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package java.testBaseServlet;

/**
 *
 * @author Administrator
 */
public class DBConn {

    private java.sql.Connection conn = null;
    java.lang.String strConn;
    java.sql.Statement sqlStmt = null; //璇彞瀵硅薄
    java.sql.ResultSet sqlRst = null; //缁撴灉闆嗗璞�

    public DBConn() {
        try {
            Class.forName("org.gjt.mm.mysql.Driver").newInstance();
            conn = java.sql.DriverManager.getConnection("jdbc:mysql://localhost:3306/testbase", "root", "root");
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }

    /**
     * @return the conn
     */
    public java.sql.Connection getConn() {
        return conn;
    }

    public void close() {
        try {
            conn.close();
        } catch (Exception e) {
            System.out.println(e.toString());
        }
    }
}
