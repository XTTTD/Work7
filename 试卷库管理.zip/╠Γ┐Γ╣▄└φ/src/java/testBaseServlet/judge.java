/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testBaseServlet;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
public class judge extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        java.sql.Connection conn = null;
        java.sql.PreparedStatement preparedStmt=null; //语句对象
        java.sql.ResultSet sqlRst = null; //结果集对象
        request.setCharacterEncoding("UTF-8");
        String test = request.getParameter("test");
        String[] tests=test.split(",");//将问题ID用逗号隔开保存，现在取出。
        String answer="";
        String testContent="";
        String url;
        int sum=tests.length;//总题数
        double count=0;//回答正确数目
        DBConn dbcon = new DBConn();
        try {
            conn = dbcon.getConn();
            for(int i=0;i<sum;i++){
                preparedStmt = conn.prepareStatement("select answer from test where testID=?");
                preparedStmt.setInt(1,Integer.parseInt(tests[i]));
                sqlRst=preparedStmt.executeQuery();
                if(!sqlRst.first()){
                    url="error.jsp?errorContent=判卷程序出错，查不到对应题的ID";
                    RequestDispatcher dispatcher = request.getRequestDispatcher(url);
                    dispatcher.forward(request, response);
                    return;
                }
                answer=sqlRst.getString("answer");
                if(answer.equals(request.getParameter(tests[i]))){
                    count++;
                }
            }
           
            int score=(int) ((count/sum)*100); 
            System.out.println(score+"##################");
            url="result.jsp?score="+score;
            RequestDispatcher dispatcher = request.getRequestDispatcher(url);
            dispatcher.forward(request, response);
        } catch (Exception e) {
            System.out.println(e.toString());
        }finally{
            dbcon.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
