/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testBaseServlet;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Administrator
 */
public class addTest extends HttpServlet {

    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        java.sql.Connection conn = null;
        java.sql.PreparedStatement preparedStmt = null; //璇彞瀵硅薄
        java.sql.ResultSet sqlRst = null; //缁撴灉闆嗗璞�
        FileInputStream fis = null;
        request.setCharacterEncoding("UTF-8");
        String testContent = request.getParameter("testContent");
        String AContent = request.getParameter("AContent");
        String BContent = request.getParameter("BContent");
        String CContent = request.getParameter("CContent");
        String DContent = request.getParameter("DContent");
        String answerSwitch = request.getParameter("answerSwitch");
        String filelocation = request.getParameter("file");
        DBConn dbcon = new DBConn();
        String url;
        if (testContent == null || AContent == null
                || BContent == null || CContent == null || DContent == null || answerSwitch == null
                || testContent.equals("")) {
            url = "error.jsp?errorContent=棰樼洰閫夐」涓嶈兘涓虹┖!";
            RequestDispatcher dispatcher = request.getRequestDispatcher(url);
            dispatcher.forward(request, response);
            return;
        }
        try {
            conn = dbcon.getConn();
            if (filelocation.length()==0) {//涓嶆彃鍏ュ浘鐗�
                System.out.println("||||娌℃湁鍥惧儚|");
                preparedStmt = conn.prepareStatement("insert into test(testType,testContent,"
                        + "AContent,BContent,CContent,DContent,answer) values (?,?,?,?,?,?,?)");
            } else {//鎻掑叆鍥剧墖
                System.out.println("||||鏈夊浘鍍弢");
                File files = new File(filelocation);
                fis = new FileInputStream(files);
                preparedStmt = conn.prepareStatement("insert into test(testType,testContent,"
                        + "AContent,BContent,CContent,DContent,answer,testImage) values (?,?,?,?,?,?,?,?)");
                preparedStmt.setBinaryStream(8, fis, (int) files.length());
            }
            preparedStmt.setInt(1, 1);
            preparedStmt.setString(2, testContent);
            preparedStmt.setString(3, AContent);
            preparedStmt.setString(4, BContent);
            preparedStmt.setString(5, CContent);
            preparedStmt.setString(6, DContent);
            preparedStmt.setString(7, answerSwitch);
            if (preparedStmt.executeUpdate() == 1) {
                //棰樼洰鍐呭澧炲姞鎴愬姛
                url = "addTest.jsp?isOk=ok";
                RequestDispatcher dispatcher = request.getRequestDispatcher(url);
                dispatcher.forward(request, response);
            } else {
                //璺宠浆鍒伴敊璇〉闈�
                url = "error.jsp?errorContent=棰樼洰鍐呭閮ㄥ垎娣诲姞澶辫触";
                RequestDispatcher dispatcher = request.getRequestDispatcher(url);
                dispatcher.forward(request, response);
            }
        } catch (Exception e) {
            System.out.println(e.toString());
        } finally {
            dbcon.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
