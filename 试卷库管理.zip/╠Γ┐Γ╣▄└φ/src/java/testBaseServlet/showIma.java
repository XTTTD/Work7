/*
 * ShowImage.java
 *
 * Created on 2007年10月25日, 上午10:49
 */

package testBaseServlet;

import java.io.*;
import javax.annotation.Resource;
import javax.naming.NamingException;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.sql.DataSource;

/**
 *
 * @author hyl
 * @version
 */
public class showIma extends HttpServlet {
    
  //  @Resource(name = "sample")
  //  private DataSource sample;
    
    /** Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        java.sql.Connection conn = null;
        java.sql.PreparedStatement preparedStmt=null; //语句对象
        java.sql.ResultSet sqlRst = null; //结果集对象
        ServletOutputStream op = response.getOutputStream();
        String testID ="";
        String url;
        testID = request.getParameter("testID");
        System.out.println("||||||||||||||||||||||||"+testID);
        DBConn dbcon = new DBConn();
        try{
            conn = dbcon.getConn();
            preparedStmt = conn.prepareStatement("select * from test where testID=?");
            preparedStmt.setInt(1,Integer.parseInt(testID));
            sqlRst = preparedStmt.executeQuery();
           if(sqlRst.first()){
                java.sql.Blob blob=sqlRst.getBlob( "testImage" );
                byte[] ab = blob.getBytes(1, (int)blob.length());
                response.setContentType("image/gif");
                response.reset();
                op.write(ab);
                op.flush();
                op.close();
            }else{
            //跳转到错误页面
                url="error.jsp?errorContent=显示图片出错！";
                RequestDispatcher dispatcher = request.getRequestDispatcher(url);
                dispatcher.forward(request, response);
            }
        } catch (java.sql.SQLException e){
            e.printStackTrace();
        }catch (Exception e){
            e.printStackTrace();
        }finally{
            dbcon.close();
        }
        
    }
    
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     */
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
    
    /** Returns a short description of the servlet.
     */
    public String getServletInfo() {
        return "Short description";
    }
    // </editor-fold>
}
